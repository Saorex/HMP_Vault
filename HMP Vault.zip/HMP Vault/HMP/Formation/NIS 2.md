# Scope :
Secteur activité - Taille (CA et nbr employé) -> essential/important
Essential (Santé, Energy, transport, water, space, bank...)
Scope Tools CCB -> help

# ISO 27001
SoA (Statement of Applicability) document central, 4 catégorie (orga, physique, human, techno)

