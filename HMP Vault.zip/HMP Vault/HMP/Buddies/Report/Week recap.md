# Week 1
Hello Benjamin,

Here is the report for my first week:

- Technical skills
    - Attended the DLP training
    - Met with PO Labs :
        - Data security (Leo Hantsch)
        - Security By Design/Cloud (Germain Boitel)
    - Requested meetings with other PO Labs
    - Used the CyFun Essential guidance to support NIS2 compliance
    - Looked into pricing for the TryHackMe premium plan
    - Sent an email to the HelpDesk to request permission to install VirtualBox for CTF practice (RootMe)
- Consulting skills
    - Started building a relationship of trust with my client
    - Analyze my client’s context
        - Directly with the client
        - Through documentation review
        - By consulting Fabio, Manuel, and Esteban, who were already working on the mission
    - Scheduled a meeting with the client for next week
- Business/mission
    - Beau Vallon mission:
        - Met with the client in person
        - Ask question about the client’s IT infrastructure
        - Reviewed documents (Policy and Process) redacted for the mission in order to better understand its scope and context
        - Assisted Fabio, Manuel, Esteban and the client to revising parts of certain documents
        - Read through the To-Do list established for the mission
        - Prepared tasks for the next meeting
    - Meet with Edouard CHON :
        - Introduced my profile, my goals for the intern and beyond
        - Asked question about the objectives of the cabinet (next challenge and growth plans)
    - Helped Sophie retrieve the company car from the garage
    - Completed all mandatory quizzes required by Headmind (SSI, Eco-Action, Digital Sustainability)

**Next steps**:

- Continue reviewing documents related to the Beau Vallon mission and complete tasks on the To-Do list
- Work towards meeting all PO Labs
- Make a decision on which lab to choose

# Week 2
Here is the report for my second week:

- Technical skills
    - Met Geoffrey for the presentation of CyberDefense Lab
    - Discovered SP 800 Measurement guide from NIST to help implement KPIs
    - Used the CyFun Essential guidance to support NIS2 compliance
    - Downloaded VirtualBox and Cisco Packet Tracer with Helpdesk
- Consulting skills
    - Communicated effectively with the client during the Beau Vallon mission day
    - Synthesized and presented past work to Charlotte during the Weekly Meeting
    - Organized and prioritized tasks for the upcoming week
    - Collaborated with internal stakeholders (Manuel, Esteban) to align on mission progress
- Business/mission
    - Beau Vallon mission:
        - Wrote a new policy (Cycle de vie des actifs et leur maintenance) and validated it with the client
        - Attended a day with my client on Tuesday
        - The Weekly Meeting
            - Met Charlotte for the first time
            - Summarized my work since the beginning of the mission to Charlotte
            - Organized and explained my priorities for next week

**Next steps:**

- Continue completing tasks on the To-Do list for the Beau Vallon mission
- Finish meeting every PO Labs
# Week 3
Here is the report for my thrid week:

- Technical skills
    - Met Antoine Bouchet for the presentation of IAM Lab
    - Writed a message to Germain to get into Cloud lab
    - Used ENISA NS2 Technical Implementation Guidance
    - Start Web Penetration Tester Path through HTB
        - Learn about XSS and CSRF
        - DNS Tools (whois, dig, dnsenum)
- Consulting skills
    - Communicated effectively with the client during the Beau Vallon mission day
    - Synthesized and presented past work to Charlotte during the Weekly Meeting
    - Started to use Obsidian to organize my work and my notes (using Git to sync it to other device)
- Business/mission  
    - Beau Vallon mission :
        - Modified an entire part about distant connection in the “Restriction d’utilisation des accès à ditance" policy
        - Created a new process: “GestionDesHabilitationsEtDesAccèsADistance”
        - The Weekly Meeting
            - Make a report to Charlotte of the week
            - Organized and explained my priorities for next week

**Next steps:**

- Continue completing tasks on the To-Do list for the Beau Vallon mission
- Continue Web Penetration Tester Path through HTB if I have time (priority to the mission)
- Get involved in the Cloud Lab 
# Week 4

- Technical skills
    - Used ENISA NS2 Technical Implementation Guidance
    - Used CYFund
    - Continue Web Penetration Tester Path through HTB
        - Finished Information Gathering - Web Edition module
    - Attended Network training
- Consulting skills
    - Communicated effectively with the client during the Beau Vallon mission day
    - Synthesized and presented past work to Charlotte and Fabio during the Weekly Meeting
    - Organized multiple meeting with my client
        - Thursday 28 May
        - Tuesday 2 June
- Business/mission  
    - Beau Vallon mission :
        - Validate the work I have done previous week with the client
            - CVD (Coordinated Vulnerability Disclosure)
            - "Gestion Des Habilitations et des accès a distance" policy
            - "Gestion Des Habilitations et des accès a distance" process
        - Asked question about how they implement security badges to structure the next policy
            - The Weekly Meeting
                - Make a report to Charlotte and Fabio of the week
                - Organized and explained my priorities for next week
    - Cloud Lab
        - Onboarding
            - Asked Geoffrey Van Palm to create an Azure account for me to participate into the Cloud Lab
            - Gived my Discord account for futher meet

**Next steps:**

- Continue completing tasks on the To-Do list for the Beau Vallon mission
    - Focus on security badges
- Get involved in the Cloud Lab
- Continue Web Penetration Tester Path through HTB if I have time (priority to the mission and lab)

# Week 5

- Technical skills
    - Used CYFund
    - Attended Headlines meeting
	    - Lab IAM PQC
	- Continued Web Penetration Tester Path through HTB
        - Tools like : nmap, netcat
- Consulting skills
    - Synthesized and presented past work to Charlotte during the Weekly Meeting
    - Anticipated Jean-Phillipe work stoppage
	    - Attended 2 meetings with the client 
	    - Asked more questions to anticipate further bottlenecks
	    - Looked for tasks I can do without the help of Jean-Phillipe (pre-drafting document without the need for full context)
- Business/mission  
    - Beau Vallon mission :
        - Worked on "Réseaux & SI" policy
		- The Weekly Meeting
			* Make a report to Charlotte of the week
			- Organized and explained my priorities for next month (without Jean-Phillipe)
		- MindHead
			- Attended a meet with Julien and Charlotte to help them implement the project
    - Cloud Lab
        - Onboarding
            - Made research about Basic Docker vulnerabilities
			    * Risk of container executed as root
				    * No USER on dockerfile
				    * Use of --priviligied option
			    * Risk of mounting in docker.sock directly on the container 

**Next steps:**

- Continue completing tasks on the To-Do list for the Beau Vallon mission
* Meet with Julien for MindHead project
- Continue get involve in the cloud lab
- Continue Web Penetration Tester Path through HTB if I have time (priority to the mission and lab)

# Week 6

- Technical skills
    - Used CYFund
    - Attended NIS2 Training
	- Made 2 labs on HTB (Reactor & Two Million)
        - Exploit nginx 
        - API injection
- Consulting skills
    - Created a TODO diagram (Excalidraw) to have a better visualization of progress on every Process/Policy 
- Business/mission  
    - Beau Vallon mission :
        - Worked on "PSSI" policy
        - Worked on "Réseaux & SI"
		- MindHead
			- Attended a meet with Julien about MindHead
				- Task distribution

**Next steps:**

- Continue completing tasks on the To-Do list for the Beau Vallon mission
- Continue get involve in the cloud lab
- Continue Web Penetration Tester Path through HTB if I have time (priority to the mission and lab)

# Week 7

- Technical skills
    - Used CYFund
    - Used Salto Space Documentation
	- Made 1 labs on HTB (Facts)
        - CVE-2025-2304 — Privilege Escalation (Cameleon CMS)
        - Use of John The Ripper
        - [GTFOBins](https://gtfobins.org/) for sudo privilege escalation
- Consulting skills
    - Communicated effectively with the client during the Beau Vallon mission day
    - Synthesized and presented past work to Charlotte
    - Asked questions to Charlotte concerning the change of Consultant on the mission (concerned about the client's reaction and the approach to have)
- Business/mission  
    - Beau Vallon mission :
        - Worked on access badge implementation with Salto
	        - Prepared a plan to help Renaud with the implementation for the access management
	        - Prepared policy and process
		- MindHead
			- Waiting for the update of the environment
	- Labs
		- Implement a basic container with security breach
			- A web application (with Flask) containing an RCE vulnerability
			- A dockerfile/docker-compose with vulnerability
				- Executed as Root
				- Mounting Docker Deamon
		- Presented my work at the Weekly meeting
		- Asked and propose perspectives for the lab to Germain (PO)
			- What types of vulnerability we want to demonstrate ?
			- What format ?

**Next steps:**

- Continue working on access badges policy/process and propose an implementation for the Beau Vallon
- Make research on more docker vulnerabilities (focus on container evasion) and then select one to implement.
- Continue Web Penetration Tester Path through HTB if I have time (priority to the mission and lab)