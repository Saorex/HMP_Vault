Faire point avec BD, parler avec le management sur des axes positifs, 

Si team pentest que du pentest. CTF entre Medium et Hard.

Voir nausica, demander les bonnes pratiques avec son équipe pour se presenter. 

Decembre/Janvier si contrat.

Même format final evaluation, point avec edouard avec présentation de ce que j'ai fait pendant mon stage, qu'est ce que je veux faire faire, qu'est ce qui m'a plus.