Retirer Junior, retirer Intern
Mettre directement tout les skills dans des bullet point. 
Mettre IaC en skills dès le début (Ansible/Terraform).
Ajouter Stakeholder communication
Mettre plus en avant la partie DevOps.

# Expérience 1 DEVOPS :
Pour l'introduction du contexte commencer par quelque chose comme: Une SME voulait développer des revenus passives. 
Plus refléter le livrable et le fonctionnement de la fin. 
Ajouter plus de détails sur le rendu des diagrammes pour avoir des données chiffrés.
Ajouter Scrum/Agile

# Experience 2 Cloud :

Mettre protection données (IAM, Top10 OWASP)

# Experience 3 GRC :
Plus de contexte, avec envergure etc... Qu'est ce qu'on devait faire exactement
Ajouter NIST
Ajouter Suite Office M365 advanced excel

# Ajouter une catégorie Academy : 
IA & Agriculutre
GameDay

Mettre une encoche JE entière comme pour mes exp