Moyen technique pour mettre en place ta stratégie de gouvernance. 

# Initialisation de vault 
Protégé par un secret. Il faut rassembler un certain nombre de personne possédant les clés pour ouvrir l'initialisation (à définir).

Quand le serveur est scellé, tu ne peux pas le configurer. Donc tu configure un serveur après l'avoir dé-scellé. Le but est donner la configuration a Terraform pour qu'il effectue la configuration après qu'on est dé-scellé le vault.


A faire dans 1-2 semaines

* Essaye de config un backend PKI de 0 via vault
* Voir que c'est plusieurs CA (donc plusieurs Backend)
* Déterminer le nombre de Backend qu'il faudra au final avec terraform
* Se rendre compte qu'à la main c'est galère
* Faire un recap de qu'on doit faire


Hierarchi de CA

Une root qui donne d'autre CA (client, serveur, mails, etc...) mais trop fragile car pas assez de degré?

Donc on crée des intermédiaire.

Root -> intermédiare -> maitrise 

Root coupé du réseaux et hebergé par un HSM (module génération de cryptographie, s'auto détruit).

CSR -> donne clée -> tu envoie en CA au dessus. Sauf que la root ne peux pas. Donc on fixe ça CA sur 20-30 ans autosignée. Et les intermédiaire sur 10 ans en gros, et les feuilles sont super courtes. 

On importe le certificat du root dans le vault, manuellement crée la CSR dans le vault puis dans root.

OpenSSL