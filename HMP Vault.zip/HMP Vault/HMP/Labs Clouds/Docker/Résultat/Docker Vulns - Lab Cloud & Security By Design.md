To start any challenges use the bash script `lab.sh`.

Challenges structure: 
The challenge is structured in two containers, one embedding the "frontend" and another one dedicated to the "backend". The frontend consists of a website where users can request elements from a database. The backend mocks the database. Users can connect to it via the login page.

# 00_Root_DockerSock & 01_noRoot_DockerSocl
## Vulnerability exploited

By default, Docker containers run as the `root` user unless a `USER` instruction is explicitly set in the Dockerfile. If an attacker obtains remote code execution (RCE) inside such a container, they immediately gain root privileges within it. This risk is compounded when containers are started with the `--privileged` flag (via `docker run` or in a `docker-compose.yml` file), which removes the security restrictions normally imposed by the Linux kernel and grants the container near-total access to the host system. Developers sometimes use this flag to bypass permission issues or to access hardware devices, without realizing the scope of access it grants.

A related and equally critical issue arises when the Docker socket (`docker.sock`), the UNIX socket through which the Docker daemon listens, with root-level access, is mounted inside a container. While this is sometimes done legitimately (e.g. by reverse proxies like Traefik, management tools like Portainer, or CI/CD agents) for automatic service discovery or container orchestration, it also gives the container the ability to communicate directly with the Docker daemon. If an attacker gains root access inside such a container, they can leverage this socket to launch a brand-new container and mount the host's root directory (`/`) into it, effectively breaking out of the container and compromising the host.

## Step by step solution

An insecure Dockerfile such as the following omits the `USER` instruction, leaving the container to run as `root`:

```dockerfile
FROM python:3.10_slim

WORKDIR /app

# No USER instruction -> container runs as root
RUN ...
EXPOSE 5000
CMD ...
```

Similarly, a container can be launched with elevated privileges either directly:

```shell
sudo docker run --privileged container_name
```

or through `docker-compose.yml`:

```yaml
services:
  web:
    image: an_image:1.0
    privileged: true
    entrypoint: ["/usr/sbin/init"]
    ports:
      - "8280:8280"
```

In both cases, once an attacker achieves RCE inside the container, they already hold root rights, and the `--privileged` flag further removes kernel-level isolation between the container and the host.

A pentester should also check whether the Docker socket has been mounted into the container, for instance via:

```yaml
services:
  flask-web:
    build: .
    ports:
      - "8080:5000"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
```

A simple way to detect this during an assessment is to check, after obtaining RCE, whether `/var/run/docker.sock` exists inside the container. If it does and the attacker has root access, they can use it to spawn a new container with the host's filesystem mounted (e.g. `/` mounted into `/mnt/host`), achieving full host compromise.

For more details about the exploit and payload check : [[Exploit CHALL 00 ET 01]]

## Fix solutions

The Dockerfile should always include an explicit `USER` instruction to run the application with a non-root, least-privileged user, so that an RCE inside the container does not automatically translate into root access.

The `--privileged` flag should be avoided whenever possible. When elevated access to specific devices or capabilities is genuinely required, it is preferable to grant only the specific Linux capabilities needed (via `cap-add`) rather than disabling all kernel-level protections.

The Docker socket should never be mounted directly into containers that are not fully trusted, since this effectively grants root access to the host through the Docker daemon. Where a container genuinely needs to manage other containers (e.g. CI/CD agents, Portainer), a safer alternative is to use a proxy such as `docker-socket-proxy`, which filters and restricts which Docker API calls the container is allowed to make.

# 02_SecreatLeak
## Vulnerability exploited
Environment variables can be inserted in a Dockerfile. While it should not contain any sensitive information, some keys or passwords can be left behind when switching to production environments. However, since they are not encrypted or stored in a secure environment, they can be recovered and used by an attacker. This is the core concept behind this challenge.

## Step by step solution
Start the challenge and go to [this website](http://4.233.75.137/).
When requesting `tomato`, the URL changes to `http://4.233.75.137/?element=tomato`.
The requests are not sanitized, making the website vulnerable to path traversal exploit.
Therefore, the exploit can be leveraged in two ways:
- Request `../proc/1/environ`
- Replace `tomato` in the URL with `../proc/1/environ`
Among the environment variables, four stand out:
- DB_IP
- DB_PORT
- DB_USER
- DB_PASSWORD
The next step is to browse to [this URL](http://4.233.75.137:5000).
Using the username and password found, it is possible to log into the database.
## Fix solutions
The best solution provided by Docker is Docker Swarm. Secrets are managed by a dedicated service. They are then accessible via a file inside the container. Data is encrypted at all time, when transferred, and when stored.
However, using Docker Swarm involves a slight change in configuration since Docker Compose cannot be used anymore. Therefore, it might be interesting to look into other, external, solutions.
One of them is HashiCorp Vault. The service is hosted on a dedicated container and act as a key manager.