![[Pasted image 20260604154212.png]]
# Execute container as root
## DockerFile
By default docker container are executed as root.
So if you don't put "USER" in the dockerfile the container will start as root
So if a user had a RCE he have directly root right

Exemple of bad dockerfile :

```dockerfile
FROM python:3.10_slim

WORKDIR /app

#No USER -> root #C'est la faille
RUN
EXPOSE 5000
CMD
```
## --privileged
```shell
sudo docker run --privileged container_name 
```
or in docker-compose
```yaml
services:
  web:
    image: an_image-image:1.0
    #Use of privileged
    privileged: true
    entrypoint: ["/usr/sbin/init"]
    ports:
      - "8280:8280"

```
Give root access to the host system

**Why developer use this** ?
* Bypass permission issues or access hardware devices.
* The privileged flag removes all security restrictions imposed by the Linux kernel on the container.
# Docker Socket
_docker.sock_ : UNIX socket where Docker Demon listening to, with root access. 
Can be mounted into a container :
```yaml
volumes:
	- /var/run/docker.sock:/var/run/docker.sock
```

**Purpose** : Container now have the right to communicate directly with Docker Deamon. 
* Can launch new container
* Auto service discovery
* Login 
* Exemple of legitimate services that needs those right : Traefik (reverse proxy), Portainer, CI/CD agents etc...
  
docker-compose with docker.sock mounted
```yaml
services:
	flask-web:
		build: .
		port:
			-8080:5000
		volumes:
			- /var/run/docker.sock:/var/run/docker.sock
```

**Exploit** :
* If you have root access you can create and execute a new container (via demaon) and mount `/` (host directory) into `/mnt/host` (container directory) for exemple

Hint for pentester to find this vuln :
* After get an RCE, check if docker.sock on /var/run/
