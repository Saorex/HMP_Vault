# Lab IAM

## PCQ
NIST -> 3 Algo (ML-KEM (General Encryption), ML DSA (Digital signature), SLH DSA (Digital signature)) check FIPS 203/204/205
2030 Transition PQC for higth risk use -> 2035 medium
Cryptographic relevant quantum computer (CRQC) expected 2035-2050

## US Regulation :
Quantum Computing CyberSecurity Preparedness Act
	Started migration in 2025
	Federal agencies must be quantum safe in 2035
NIST IR 8547

## French regulation
Ask for a visa pre quantum safe 2035


