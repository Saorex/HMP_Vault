Serveur peut tout faire

OT 
* Medical : (Tension, thermometre, electrophisiologie)
	* Medical policy en brouillon sur filao
* OT Sonde, relai technique, transformateur contact sec, RS232 vers IP 

# Segmentation IP
## Range 1 with routing
212.166.58.176 = réseau (net ID)
212.166.58.177 = routeur côté WIN
212.166.58.178 = exchange (smtp, owa) ([mon.beauvallon.be](https://linkprotect.cudasvc.com/url?a=https%3a%2f%2fmon.beauvallon.be&c=E,1,6893guV1AWBTm8lp-b6LADfObaQdQifqSFgIMFB0n-Nszmcdw2nRzvjevq-B8P3jeKuOYKvvycYyKItrkX0RcOQUtFTqAXgSSCb4JToTQerswDwqVhxm&typo=1&ancr_add=1))
212.166.58.179 = speech exec mobile
212.166.58.180 = routeur fibre DR
212.166.58.181 = routeur redondance COAX
212.166.58.182 = firewall main IP + [vpn.beauvallon.be](https://linkprotect.cudasvc.com/url?a=https%3a%2f%2fvpn.beauvallon.be&c=E,1,e6rvDsoevgZLsLNYED6QBe4LlOtu393HGJjDUCSp4GiOXvN8m6Sl51y0mo9MvyBj4R9c_sydHFJhGFDHURXWPue9itojiDh_u0xtvk0ZdvSuBcEM_mQNIKWD2oY,&typo=1&ancr_add=1)
212.166.58.183 = le broadcast

## Range 2
212.166.19.148 = [pep-pocket.beauvallon.be](https://linkprotect.cudasvc.com/url?a=https%3a%2f%2fpep-pocket.beauvallon.be&c=E,1,mbfVlH9tDzYgy_Jm9KY5_VaiOwKhqccdyLh2GX9mYmqLCbYtqBF_iCKjQ1qVyYnWjqgsbt9lDJ4C2OKwwTFsut7P4dkKX-zJyxC9AfBpzS9gpIWCLLWYIsA,&typo=1&ancr_add=1)
212.166.19.149 = pepsagenda mobile
212.166.19.150 = [masession.beauvallon.be](https://linkprotect.cudasvc.com/url?a=https%3a%2f%2fmasession.beauvallon.be&c=E,1,sz7OAEs8gU6Nz9ev5grCvwAC2NRU_v-yzTQpIRxHCZcjtORTVAENSFal3Kn4XEXujdfeK-JTkhUv1eCCVqJU6s246f9LLKne8zBkGx5iJ-2KRCyhgyjKIj0,&typo=1&ancr_add=1) / [masession.lesgoelands.be](https://linkprotect.cudasvc.com/url?a=https%3a%2f%2fmasession.lesgoelands.be&c=E,1,I5u-rCaiSl_attLJYi2knxLfA0kfbYiIbMSqORCSR-LmFlE-sAKAZEQSw3RD2pns_uboNTySwKTv5ZA6_rtxGNebbMZy8N5FpTPTh1xeSNbXpRCZ1VqyuN2ciSSx&typo=1&ancr_add=1)
212.166.19.151 = [exhybrid.beauvallon.be](https://linkprotect.cudasvc.com/url?a=https%3a%2f%2fexhybrid.beauvallon.be&c=E,1,pyJQgGPYZ1O2MO5MhGBUd8ErEKzitTHFKdisX57k-5C2WCFzvJ6APxEh_8NmLIPSUVf4mEJydTyfVRh--WFo3lJc8sE-KLetTHRMOMQpSdB2FqhQnsMcBp4SKg,,&typo=1&ancr_add=1)

## Range 3
212.166.56.92 = not in use
212.166.56.93 = [pep-pocket.lesgoelands.be](https://linkprotect.cudasvc.com/url?a=https%3a%2f%2fpep-pocket.lesgoelands.be&c=E,1,Gp0VCCfKtRHNQyCd8nZmUNeFtp7l-7PIRs4cBbfITzlT1BUlYAsspTOCJXBxiL-uiBuChE2hfc8Y_uR3X7n2wLdKGUnTYZOohFlqVzPVhWz9_Q,,&typo=1&ancr_add=1)
212.166.56.94 = not in use
212.166.56.95 = not in use

## Range 4
212.166.57.84 = not in use
212.166.57.85 = Aruba RAP MD-1
212.166.57.86 = Aruba RAP MD-2
212.166.57.87 = Aruba RAP VRRP

## VLAN
Voir registres VLAN filao