C’est en cours de mise en place.
Accès physique (clés, portail) : Département technique (Stéphane) géré clefs portail etc… 

# Accès badges :
2 types de lecteurs de badge :
* Connecté (permet la diffusion de changement des droits)
* Non Connecté

Objectif : Avoir accès qu’aux locaux nécessaires (moindre accès) par fonction

Passe-partout général : pour intervention incendie ou services techniques

Nomenclature accès Porte BV17_Porte16 -> carte pour se retrouver dans les noms

Fonctionnement par Zone : exemple zone Infermier, zone Psychiatre. Ce qui donne un accès usager.

Tout le monde doit pouvoir accéder aux espaces usuelles porte principale/wc sans pour autant pourvoir avoir accès aux services.

Faire valider par Patrick Directeur Technique.

Mettre des badges temporaires à l’accueil ?

Faire que chaque porte d’entrée dans un bâtiment soit avec un lecteur de badge connectée pour mettre à jour.

--- 

- **Les Zones :** Ce sont de simples groupes de portes physiques (ex: "Toutes les portes RH"). Elles s'associent aux _User Access Levels_ (Niveaux d'accès), et non aux _Functions_.
    
- **Les Locations & Functions :** C'est un système de "matrice". Les _Locations_ et les _Functions_ s'attribuent directement aux **Portes (Access points)** d'un côté, et aux **Utilisateurs** de l'autre.


### **Option 1 : La méthode matricielle (Locations & Functions)**

Au lieu de créer des zones, vous utilisez un croisement direct de données :

1. **Créer les Locations :** Bâtiment A, Bâtiment B, Bâtiment C.
    
2. **Créer les Functions :** RH, Serveurs, Secrétariat, Maintenance, Entrée Principale.
    
3. **Configurer les Portes :** Vous attribuez à chaque porte sa "coordonnée".
    
    - La porte du bureau RH du Bâtiment A est configurée avec -> Location : _Bâtiment A_ | Function : _RH_.
        
    - La porte d'entrée principale du Bâtiment A est configurée avec -> Location : _Bâtiment A_ | Function : _Entrée Principale_.
        
4. **Attribuer les droits aux Utilisateurs :** Vous donnez les "coordonnées" de ce croisement à vos employés.
    
    - Un employé RH du Bâtiment A recevra -> Location : _Bâtiment A_ **ET** Functions : [_RH_, _Entrée Principale_]. Il ouvrira automatiquement toutes les portes correspondantes.
        
    - Un technicien réseau global recevra -> Locations : [_Bâtiment A_, _Bâtiment B_, _Bâtiment C_] **ET** Functions : [_Serveurs_, _Entrée Principale_].
        

> **Note technique importante :** La fonctionnalité _Locations/Functions_ dépend de votre licence Salto. L'énorme avantage de cette méthode est qu'elle préserve la mémoire des badges physiques (les clés RFID Salto ont une mémoire limitée, souvent autour de 230 bytes). Réduire le nombre de groupes préserve cette mémoire.

### **Option 2 : La méthode classique (Zones & Niveaux d'accès)**

_Si l'onglet "Locations/Functions" n'est pas actif dans votre licence (dans System > General options), c'est l'architecture standard qu'il faudra adopter._

Ici, la logique matricielle n'existe pas, on construit l'arborescence manuellement pour chaque cas :

1. **Créer les Zones :** Vous regroupez vos portes pour chaque bâtiment.
    
    - Zone "Entrée Bâtiment A"
        
    - Zone "Bureaux RH Bâtiment A"
        
    - Zone "Serveurs Bâtiment A"
        
2. **Créer les User Access Levels (Niveaux d'accès utilisateurs) :** Ils représentent les profils métiers complets par bâtiment.
    
    - Créer un niveau "Profil RH - Bâtiment A" (qui englobe la Zone "Entrée Bâtiment A" et la Zone "Bureaux RH Bâtiment A").
        
3. **Attribuer aux Utilisateurs :** Vous assignez simplement le niveau d'accès "Profil RH - Bâtiment A" à l'employé concerné.
    

Cette méthode est très visuelle, mais si vous avez 10 bâtiments et 10 services, vous devrez créer et maintenir manuellement 100 niveaux d'accès différents.