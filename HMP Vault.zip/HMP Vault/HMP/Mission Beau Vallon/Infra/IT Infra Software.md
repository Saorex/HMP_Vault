# Fortigate 
2 firewall :
* Interne
* Externe
Cloud + FortiAnalyser
2 Zone internet (Pro et Guest)

# Darktrace
* Analyse tout le traffic réseaux
	  Fonctionne par comparaison du traffic "habituel et actuel" -> Comportement
* Analyse de mail
  Après Windows Defender, fonctionne aussi par comportement
# EDR TrendAI Vision ONE
# Secteer VulnDetect
* Analyse de Vuln
* Patching machines du parc
# OutKept (Awarness)
# ClearPass (NAT
# Imprivata
* One client auth : Badge + PIN
	* Sans badge : CREDS + Question de sécu
		* 200 essaies
* Autocompletion (SSO) sur les login de software

# Papercut
* Imprimante
# AKCP
* Monitoring Data Center
# SolarWinds
* Monitoring
# Salto
* Techno sécu des badges