![[Diag TODO par Pol&Pro]]

Pour les questions/réponses d'hier en rapport avec la gestion des actifs (il y a peut être des q&a en plus et en moins):

 - [x] Comment les câbles d'alimentation et de données sont-ils protégés contre les dommages physiques (goulottes, faux plafonds, câbles non apparents, matériaux spécifiques) ?  Surveillé par vidéo surveillance. Alimentation électrique doublé.
- [x] À quelle fréquence ces protections physiques sont-elles vérifiées ?  Une fois par ans (à mettre dans la proc de gestion des actifs), clim 2 fois par an mini. Préciser avec qui on a les contrats de maintenances et qui contacter. UPS: Eaton; Générateur électrique: SAG Electrogène SRL; Clims: Reflow; Incendie, détection des fuites d'eau, etc.: Somati Systems et Chubb
- [x] Existe-t-il un schéma ou une cartographie à jour du réseau ?  
    => Topologie du réseau filaire. 3 outils : fw fortigate qui montre la topologie du réseau filaire, les Aruba Mobility Condutcor pour la topo du réseau sans fil et le réseau hertzien de DR, page web pour la topo.
- [x] Comment un nouvel équipement réseau est-il sécurisé et ajouté à l'inventaire ?  
    => Via NAC (Aruba ClearPass)
* [x] Quelle solution EDR est utilisée sur les postes et sur les serveurs ? Est-ce la même ? Sur quoi repose la détection (signatures, analyse comportementale, machine learning, etc.) => - TrendAI Vision One (voir proc gestion des actifs pour les policies). Dépend de la baseline (cf la proc de gestion des actifs, peut être éditer la proc pour détailler les policies)