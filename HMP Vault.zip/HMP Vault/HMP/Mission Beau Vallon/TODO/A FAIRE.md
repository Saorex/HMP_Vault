* Prendre contact pour savoir si on doit faire les contrats avec les fournisseurs non IT
* GV.SC-05.2 -> A valider CC
* GV.SC-06.1 -> 
* GV.SC-10.1 -> 