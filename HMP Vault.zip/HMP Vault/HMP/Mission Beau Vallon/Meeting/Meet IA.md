Date: 01/06/2026
Personnes présentes : Charlotte Cerracchio / Julien Reynaud
 ***
Se base sur les docs pdf pour le moment
Voir score donné pour le basic et comparé avec l'audit sur le CYFun Basic

Pour le moment document 1 par 1

Faire Travail d'analyse de donnée

Faire un meet début vendredi 3 juillet pour voir l'avancement. Commencer à faire les comparaison, remonté point négatif du projet et voir si faire de la doc pour essentials.
