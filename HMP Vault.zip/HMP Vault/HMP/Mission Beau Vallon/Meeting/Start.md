rdv tour 7H mercredi
2 fois par mois 

jean philipe respo infrastructure > rencontre friterie

Prévoir réu teams Fabio MENEGAZZI et charlotte CERRACCHIO (contexte mission, rencontre) -> Se présenter

Hopital equipe de 5 Directeur pierre Yves, Respo IT Jean phillipe (fait tout, a lui de poser des questions, faire un review de l'infra)

CCB
Excel fait avec to do list pour compliance NIS2, 
Convention nommage
Complient basic mais veulent passer a Essentials.

Pour ecrire procédure partir de la Template procédure

Faire les KPI essentiels

Politique : Vision globale ( qu'est ce que tu dois faire) (ex: PSSI
Procédure : Comment tu le fais