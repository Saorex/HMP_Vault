Application métier en dur (pas web). Platforme WinDev. Pas de library externe que outils natif de windev.

Sécurisation d'accès : login des sessions définie via les accès en fontion du DPI Accès syncro avec DPI.

Serveur test dans le DPI (xCare). Les accès DPI sont géré via xCare.

xCare fait la gestion des droits. 
xCare data : Accès directement des donnés.

Chaque compte à droits à des accès différents

Environment de test aussi utilisé pour les formations. Donnée restrainte non syncro avec la prod. Il y a des vraies données patients (mais ancien) Pour autant en formation chacun n'a accès aux données que de ses patients.
ON est obligé de mettre des vraies données pour les test.  

Connexion a distance possible pour réaction

Cycle de développement : 

Windev : historique des codes sources. Tout est stockée dans le GDS pas en local. Extraction des données puis renvoie après modifiaction. Tu gardes un historique qui te permet de faire un rollback ou vérifier ce qui a été changé. Sur le serveur on garde toujours l'ancienne version du binaire (.exe) et le nouveau en cas de problème pouvoir switch. Auto update PC SOFT de donne les dernières maj de windev.
Utilise qu'une branche. 

En pratique : on se penche directement sur les droits, et les accès. 

Passage en production fait par Rity, bien fait en simulation sur un enviromment d'acceptance.

Pour accéder au GDS il faut faire une exception sur le firewall, ce qui fais que personne ne peut se connecter sans crée l'exception

Définir test de routine

SSO windows

Se basé sur OWASP

Logs des accès sur xCare. 

___

# Retour Rithy sur procédure

Refaire partie 4
* Trop cibler sur le cas des programmes utilisant le DPI
	* Fractionner avec un partie xCare sur la partie donnée patient on fait ainsi
	* Accès aux données très globale puis le cas du DPI.


