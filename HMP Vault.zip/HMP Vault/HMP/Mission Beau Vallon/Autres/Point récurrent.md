* PSSI et notes de gouvernance : 1 an par Comité de Direction
	* doit être effectuée au minimum une fois par cycle de certification (par exemple, lors des audits de sécurité ou des certifications en matière de protection des données).
  
* Les révisions périodiques des accès aux zones critiques sont coordonnées avec le comité de direction au minimum une fois tous les 2 ans et sont documentés dans le registre de révisions des accès physiques (politique des gestions des habiltiations et accès)
  
* Campagnes de revalidations des droits : **au moins une fois par an** (ou tous les 6 mois pour les accès sensibles). (Politique des gestions des habiltiations et accès)
  
* Plan de formation et de sensibilisation à la cybersécurité élaboré et mis a jour sous 1 an
  
* Pour IT : Audit droit (**au moins une fois par an** (ou tous les 6 mois pour les accès sensibles)).

* Registre des exceptions historiques : liste sera suivie et révisée chaque année par le Comité Informatique.

*  KPIs sont définis et revus trimestriellement dans le registre des KPIs

Faire document planning de contrôle