Politiques :
* Pour visiteur (fournisseurs) : 
	* En journée : demander une "caution" d'identité qui sera remise à l'accueil.
	* En soirée (quand l'accueil ferme après 21H) : contacter sur le 111 qui dévie sur un membre du personnel pouvant faire la remise de la pièce d'identité. 
* Stagiaire :
	* Ils doivent rapporter le badge tout les jours et le récupérer chaque jour.
	* Faire un listing badge - identité, et demander une caution d'identité.
* Badge "Tête en l'air"
	* Pour un oubli de badge
	* Faire un bon suivi (carte d'identité)
		* ~~Option 1 : Faire un doublon des droits de la personne temporaire (valable 12 h seulement)~~
		* ~~Option 2 : Donner tous les droits sur le badge~~
		* Option 3 : Faire 2 badges par services + 2 équipes mobiles (s'assurer d'avoir un bon suivi des badges). Si pas de rendu de badge en fin de journée, faire la demande de désactivation au service informatique
* Salle de réunion :
	* Accès seulement à la salle X
	* Un badge par salle de réunion
	* Caution d'identité
* Prendre rdv avec Francois pour la relecture de la politique et de la procédure (mercredi 23 septembre 9H30-11h)
* Sécuriser l'armoire à clefs et à badges
	* Actuellement elle est dans l'accueil et certaines personnes se servent sans demander.
* Réunion gestion clefs physique 


Procédure :
* Centraliser au service technique la gestion des badges
	* Mettre en place un agenda ?
* Créer une fiche électronique (avec nom, prénom, téléphone) et faire signer
	* Archiver et centraliser le contrôle
		* Identifier une personne qui a fait plus de X demandes
		* Suivre le rendu