
GSM que le BV fournit (android ou apple), chacun sa config

* IOS
	* Profil entreprise, géré entièrement par l'employeur
		* Exemple : peut bloqué capture, imposer mots de passe...
	* Bring your own device : travail sur le profil user
		* Bloquer l'adresse BV que sur l'outlook entreprise que le BV control
* Android
	* Profil entreprise + perso = BYOD
		* Play store entreprise,
		* Application obligatoire 
		* Application non obligatoire
	* Profil entreprise full manager par l'entreprise
	* Profil full BYOD
		* Tu télécharge une application qui te donne les instructions

BV_Android_BYOD_CFG_WorkProfile_Restrictions

Configuration géré par groupe.
Conformité : Pour bloquer l'accès si pas dans une version trop antérieur à ce qu'à choisit le BV