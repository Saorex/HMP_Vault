Note de Gouvernance :

·       Qui est le : responsable infrastructure IT ? Il n’est pas présenté dans les acteurs
·       5.3 Il faut inclure le Responsable de la Sécurité Informatique dans l’équipe informatique ?

Contrôle 

|                |                                                                                                                                                                                                       |
| -------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **RS.MI-01.2** | _The organisation shall detect unauthorised access or data leakage and take appropriate mitigation actions, including monitoring of critical systems at external boundaries and key internal points._ |

 * **Monitor Critical Systems**: Monitoring should be implemented at external network boundaries and key internal points to detect anomalies or unauthorised access attempts.
	 * Doc
		 * Pol_ProtectionDesdonnées (4.),
		 * Pro_GestionDesIncident (2.)
 * **Protect Data in All States**: Data should be protected using encryption, digital signatures, and cryptographic hashes to ensure confidentiality and integrity during storage, transmission, and use.
	 * Doc : 
		 * Pol_ProtectionDesDonnées (4.)
		 * Pro_GestionDesPériphériquesAmovibles
		 * Manque Procédure de manière général
 * **Control Outgoing Communications**: Outbound communications containing sensitive data should be automatically blocked or encrypted based on data classification.
	 * Doc : 
		 * Pol_ProtectionDesDonnées (4.), 
		 * Pro_GestionDesMails (3.),
		 * Pol_GestionDesInventairesDesRegistresEtDesFluxDeDonnées (4.)
 * **Restrict Use of Personal Services**: Access to personal communication platforms (e.g. personal email, file-sharing services) from organisational systems should be restricted to reduce the risk of data leakage.
	 * Doc : Pol_GestionDesHabilitationsEtDesAccès (3.2),
	 * Pol_RestrictionsD_UTilisationDesAccèsADistance (3.1, 3.2, 3.3, 3.4, 3.5)
 * **Prevent Data Reuse in Non-Production Environments**: Sensitive production data should not be reused in development or testing environments unless properly anonymised or masked.
	 * NA ?
 * **Clear Temporary Data:** Sensitive data should be cleared from memory or temporary storage once it is no longer needed.
	 * Je ne sais pas
 * **Audit Identity and Access Management:** Systems such as Microsoft Active Directory should be regularly audited, with a focus on privileged accounts and access control consistency.
	 * Doc : Pol_GestionDesHabilitationsEtDesAccès (7.5, 7.6, 8.1, 8.2, 8.3)
 * **Ensure OT-Specific Feasibility** : In OT environments, detection and mitigation measures should be adapted to avoid disrupting safety or operational continuity. Passive monitoring and interface-level logging may be used where direct integration is not feasible.
	 * Doc :
 * **Align with ENISA Guidance** These practices align with ENISA’s Threat Landscape Reports and Information Leakage Guidance, which provide recommendations for detecting and mitigating data breaches and unauthorised access.
	* ok avec le reste

Audit :

Phase 1: Self assestment controle  
5-6 semaine puis  
Phase 2 : echantillonage KPI
