- <font color="#ff0000">Inventory and Control of Enterprise Assets</font>
	- KPI Management
	    - **Taux de couverture de l'inventaire :** Pourcentage d'équipements informatiques identifiés et gérés par rapport à l'estimation totale du parc.
    - KPI Opérationnels
	    - **Volume d'actifs non autorisés :** Nombre d'équipements non reconnus bloqués ou mis en quarantaine par le contrôle d'accès réseau (NAC) par mois.
	    - **Surveillance d'obsolescence :** Nombre d'assets critiques qui n'ont pas reçu de maintenance depuis 1 an.

- <font color="#ff0000">Inventory and Control of Software Assets</font>
	- KPI Management
	    - **Taux de conformité logicielle :** Pourcentage des postes de travail n'exécutant que des applications approuvées.
	    - **Risque d'obsolescence :** Pourcentage de logiciels critiques fonctionnant sur des versions en fin de vie (End of Life) non supportées par l'éditeur.
	  - KPI Opérationnels
	    - **Tentatives d'exécution illicites :** Nombre d'applications non autorisées (ou malveillantes) bloquées par les règles de contrôle d'application par mois.

- <font color="#ff0000">Data Protection</font>
	- KPI Management
	    - **Couverture de protection des données de santé :** Pourcentage de bases de données contenant des données à caractère personnel de santé (DPI) soumises à un chiffrement au repos.
	    - **Volume de fuites de données :** Nombre d'incidents ayant entraîné une divulgation non autorisée de données sensibles.
	- KPI Opérationnels
	    - **Détections DLP (Data Loss Prevention) :** Nombre d'alertes générées pour des transferts de données sensibles vers des destinations à priori non autorisées.
	    - **Taux de chiffrement :** Pourcentage d'unité de stockage ayant le chiffrement au repos.

- <font color="#ff0000">Secure Configuration of Enterprise Assets and Software</font>
	- KPI Management
	- KPI Opérationnels
		- **Taux de conformité au baseline :** Pourcentage d'équipements conformes aux configurations définies par les baselines.

- <font color="#ff0000">Account Management</font>
	- KPI Management
	    - **Campagnes de droits :** Nombre de campagnes contrôles revalidation des droits de revalidations des droits
	    - **Campagnes de cohérences des habilitations :** Nombre de campagnes de contrôles de cohérences des habilitations
		- **Comptes orphelins :** Nombre de comptes orphelins révoqués
	- KPI Opérationnels

- <font color="#ff0000">Access Control Management</font>
	- KPI Management
	    - **MFA :** Pourcentage des accès distants et accès privilégiés protégés par une authentification forte.
	    - **Incidents d'accès illégitimes :** Nombre d'escalades de privilèges non autorisées ou d'accès réussis depuis des localisations suspectes.
	- KPI Opérationnels
	    - **Échecs d'authentification :** Nombre de tentatives de connexion refusées (brute-force ou mots de passe erronés) par mois.

- <font color="#ff0000">Continuous Vulnerability Management</font>
	- KPI Management
	    - **Indice de risque des vulnérabilités :** Nombre de vulnérabilité suffisamment critiques pour que le fabricant/éditeur nous alerte.
	    - **Respect des SLA de patching :** Pourcentage de vulnérabilités critiques corrigées dans le délai imposé par la politique de sécurité.
	- KPI Opérationnels
		- **Correction des vulnérabilités critiques:** Nombre de vulnérabilités critiques corrigés sur la période
		- **Correction des vulnérabilités non critiques:** Nombre de vulnérabilités non critiques corrigés sur la période

- <font color="#ff0000">Audit Log Management</font>
	- KPI Management
	    - **Couverture de la centralisation des logs :** Pourcentage de systèmes critiques envoyant effectivement leurs journaux vers le SIEM (Wazuh).
	    - **Conformité légale de rétention :** Pourcentage des catégories de logs conservés conformément aux durées définie dans la politique sans altération.
	- KPI Opérationnels
		- **Pertinence des alertes SIEM (Wazuh) :** Ratio du nombre de vrais incidents de sécurité par rapport au nombre total d'alertes générées.

- <font color="#ff0000">Email and Web Browser Protections</font>
	- KPI Management
	    - **Taux d'efficacité du filtrage mail :** Pourcentage d'emails malveillants (phishing, malware) bloqués avant d'atteindre les boîtes de réception des agents.
	    - **Filtrage web :** Nombre d'accès web filtrés (définir prompt Forti IA)
	- KPI Opérationnels
	    - **Volume de menaces arrêtées :** Nombre total de campagnes malveillants (phishing, malware) bloqués par mois.
	    - **Signalements utilisateurs :** Nombre d'emails suspects remontés par les utilisateurs via le bouton de signalement.

- <font color="#ff0000">Assets protection</font>
	- KPI Management
	    - **Taux de couverture EDR/Antivirus :** Pourcentage des actifs connectés équipé d'une solution de protection active.
	    - **Assets sans protection :** Taux d'assets sans aucune protection
	- KPI Opérationnels
		- **Assets sans protection :** Nombre d'assets sans aucune protection
	    - **Assets avec protection limité :** Nombre d'assets avec une protection limité

- <font color="#ff0000">Data Recovery</font>
	- KPI Management
	    - **Backups :** Nombre de test de restauration de backup réussie / Nombre de test de restauration de backup total
	    - **PCA :** Test (binaire) PCA (Plan de Continuité d'Activité) menés sur la période évaluée.
	    - **PRA :** Test (binaire) PRA (Plan de Reprise d'Activité) menés sur la période évaluée.
	- KPI Opérationnels
	    - **RTO Opérationnel observé :** Temps moyen réel mis par l'équipe pour restaurer un DPI fonctionnel depuis les PC portables lors du dernier incident ou test (1 fois par an).
	    - **Dispositions applications critiques :** Taux de disponibilités des applications critiques (DPI,...)

- <font color="#ff0000">Network Infrastructure Management</font>
	- KPI Management
	    - **Indice de segmentation du réseau :** Pourcentage de l'infrastructure où les flux réseaux sont cloisonnés entre eux.
	    - **Indice ségrégation du réseau :** Pourcentage de l'infrastructure où les flux réseaux d'une segmentation sont cloisonnés.
	    - **Conformité de l'architecture :** Pourcentage des équipements réseaux administrés via des protocoles sécurisés contre les protocoles clairs.
	    - **Indice de taille du réseaux:** Nombre de sous-réseaux monitorés 
	- KPI Opérationnels
	    - **Firewall Policy :** Le nombre de firewall policy qui n'ont pas été utilisé au cours d'une période.
	    - **Contrôle d'équipement par le Firewall :** Le nombre d'équipement potentiellement compromis d'après le Firewall en dehors du réseau Guest

- <font color="#ff0000">Network Monitoring and Defense</font>
	- KPI Management
	    - **Couverture de la détection réseau (NDR) :** Pourcentage du trafic réseau interne et externe supervisé en dehors du réseau guest.
	    - **Tendances des attaques ciblées :** Évolution par an du nombre d'attaques majeures (scans massifs, tentatives d'exploitation) bloquées aux frontières de l'établissement.
	    - **Temps gagné :** Nombre d'heure d'économie humaine
	- KPI Opérationnels
	    - **Mean Time To Respond :** Délai moyen pour que la supervision réseau détecte un une anomalie à bloquer.
	    - **Mean Time To Acknowledge :** Délai moyen que l'équipe informatique prend pour avoir connaissances des anomalies.
	    - **Détection des comportement anormaux :** Nombre de comportement anormaux détectés
	    - **Flux non documentés :** Nombre de flux réseaux atypiques ou chiffrés inconnus découverts en sortie vers Internet.

- <font color="#ff0000">Security Awareness and Skills Training</font>
	- KPI Management
		- **Réalisation des formation cyber CoDir :** Taux de complétion des formations cyber effectué par les membres du CoDir
		- **Réalisation des formation cyber en ligne :** Taux de complétion des formations cyber en ligne envoyé (objectif qu'on veut faire)
		- **Réalisation des formation cyber obligatoire :** Taux de complétion des formations cyber obligatoire (objectif qu'on veut faire)
	    - **Phishing :**  Taux de compromission aux campagnes de phishing organisé
		- **Phishing :** Nombre total de mail de test depuis le début
	    - **Phishing :** % de personne qui se sont fait avoir 
	    - **Phishing :** % de personne qui ont partagé des informations vers le lien
	    - **Phishing :** % de personne qui ont ouvert une pièce jointe
	  - KPI Opérationnels

- <font color="#ff0000">Service Supplier Management</font>
	- KPI Management
		- **Suivi des contrat cadre cyber :** Pourcentage de fournisseurs ayant signé un contrat cadre cyber.
		- **Suivi des contrat cadre cyber :** Nombre de contrat cadre cyber envoyées pour les fournisseur.
	    - **Suivi des questionnaire cyber :** Nombre de fournisseurs ayant répondus au questionnaire de sécurité.
	    - **Criticité des fournisseurs :** Nombre de fournisseurs critiques, moyen et faible
	- KPI Opérationnels
	    - **Incident interne du à une faille fournisseur :** Nombre d'incidents de sécurité interne à l'institution ayant pour origine une faille ou une négligence chez un fournisseurs.
	    - **Suivi des incident d'un fournisseur :** Nombre d'incidents de sécurité chez un fournisseur qui n'a pas eu d'impact de sécurité chez nous.

- <font color="#ff0000">Application Software Security</font>
	- KPI Management
	    - **Couverture des audits applicatifs :** Pourcentage des applications web exposées sur Internet ayant fait l'objet d'un audit de sécurité ou d'un test d'intrusion récent.
	- KPI Opérationnels
	    - **Délai de correction des failles :** Temps moyen mis par l'éditeur du logiciel (ou l'équipe de développement) pour fournir un patch après la découverte d'une vulnérabilité critique par le Beau Vallon suite à un audit applicatif.

- <font color="#ff0000">Incident Response Management</font>
	- KPI Management
	    - **Préparation à la crise :** Nombre d'exercices de simulation de crise cyber réalisés dans l'année incluant au moins un membre du CoDir, un membre du service informatique, et au choix d'un exercice à l'autre divers rôles (DPO, Conseil en prévention, CFO, Chargé de communication, ...)
	    - **Respect des délais de déclaration :** Pourcentage d'incidents majeurs notifiés aux autorités compétentes dans les délais légaux définies.
	    - **Impact sur l'activité :** Nombre d'incidents de sécurité ayant eu un impact sur l'activité de soin.
	- KPI Opérationnels
	    - **MTTR (Mean Time To Respond) :** Temps moyen entre la confirmation d'un incident de sécurité par l'incident respond team et la neutralisation de la menace.
	    - **MTTR (Mean Time To Recover ) :** Temps moyen entre la confirmation d'un incident de sécurité par l'incident respond team le retour à la normal.

- <font color="#ff0000">Penetration Testing</font>
	- KPI Management
	    - **Taux de remédiation post-audit :** Pourcentage de vulnérabilités critiques et hautes corrigées suite au dernier rapport de test d'intrusion.
	- KPI Opérationnels
	    - **Détection des tests d'intrusion :** Pourcentage d'actions offensives réalisées par les pentesteurs qui ont été effectivement détectées par les équipes internes et le SIEM.

- <font color="#ff0000">Gouvernance, Risques et Conformité</font>
	- KPI Management
	    - **Suivi des lois applicables:** Taux d'avancement des mises en conformité des lois applicables
	    - **Respect des politiques :** Nombre de fois où une politique de sécurité n'a pas été respectée.
	    - **Respect des procédures :** Nombre de fois où une procédure de sécurité n'a pas été respectée.

- <font color="#ff0000">Gestion des Ressources (Budget et Humain)</font>
	- KPI Management :
	    - **Gestion du budget Cyber :** Budget Cyber évalué / Budget Cyber utilisé (Suivi de l'enveloppe allouée vs consommée).
	    - **Gestion du budget global :** Budget Global évalué / Budget global utilisé (Pour situer le poids relatif de la cyber par rapport à l'IT global).
	    - **Gestion de l'ETP Cyber :** ETP Cyber évalués / ETP Cyber utilisés
	    - **Gestion de l'ETP Global:** ETP globaux évalués / ETP globaux utilisés.
- Risk management
	- KPI Management 
		- 
	- KPI Opérationnels
		- % de risques cloturés sur une période donnée
		* Nombre de risques acceptés sur une période donnée 
		* Nombre de risques identifiés par un fournisseur/parti externe et communiqué par le Beau Vallon