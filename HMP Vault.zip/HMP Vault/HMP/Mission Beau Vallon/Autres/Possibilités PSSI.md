# PR.PS-06.2
Tout changement ou dérogation appliqué à un système en production fait l'objet d'une validation formelle préalable, incluant une évaluation des risques associés. Les risques acceptés sont documentés et réexaminés périodiquement afin de s'assurer que leur acceptation reste justifiée.

# PR.PS-06.4
Tout changement planifié sur un système critique fait l'objet d'une analyse d'impact sécurité préalable, réalisée dans un environnement de test isolé et représentatif de l'environnement de production, avant toute mise en œuvre opérationnelle.