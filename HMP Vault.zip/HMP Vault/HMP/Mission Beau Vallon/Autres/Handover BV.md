Présentation :
* Moi
* Daniel
* Lui
* D'autres missions ?

Compliance NIS2
* Exp érience ?
* CyFun ?
* Différence politique/procédure

Info client :
* Beau vallon hopital psy
* Petite équipe info
* Jean-philippe +++
* Parc assez grand et équipé
* Basic l'année dernière
* Objectif essential avril 2027
	* Base de l'audit précédent -> TODO


Point agenda