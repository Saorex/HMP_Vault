# Point Positif
* Cohérent avec ce qu'implique une exigence et les manquements qu'il peut y avoir par rapport à celle-ci sur les documents concernés
* Identification claire des sources dans tous les cas
	* Permet d'identifier rapidement les endroits où il faut corriger
* Génération de la matrice de conformité (manque une colonne id exigence)
# Point Négatif
* Pas d'intégration d'autres formats que le PDF.
* Dépôt des documents 1 à 1
* Notation sans rapport direct avec le CYFun (1-5)
* Absence d'exclusion de certains points N/A (exemple OT : PLC)
* Pas d'accès à la documentation.
* Pas sur la dernière version.

# Remarques
## Exemple
### Version exigent
![[Pasted image 20260626094636.png|245]]
L'exigence de cybersécurité indique que l'activité de journalisation de la protection/détecteuse de hardware ou de logiciel (par exemple, pare-feu, anti-virus) doit être activée, sauvegardée et examinée. <font color="#ff0000">Cependant, le document fourni ne mentionne pas explicitement que l'activité de journalisation est activée, sauvegardée et examinée.</font> Bien que le document mentionne la politique de gestion des logs et la protection des logs, il n'est pas clair si l'activité de journalisation de la protection/détecteuse de hardware ou de logiciel est spécifiquement mentionnée et respectée. Par conséquent, il est difficile de déterminer si l'exigence de cybersécurité est respectée.

### Version intermédiaire
![[Pasted image 20260626144634.png|231]]
L'orientation est non conforme car :

L'exigence de cybersécurité indique que l'activité de journalisation de la protection/détecte du matériel ou du logiciel (par exemple, les pare-feu, les anti-virus) doit être activée, sauvegardée et examinée. <font color="#ff0000">Cependant, le document fourni ne mentionne pas explicitement que l'activité de journalisation est activée, sauvegardée et examinée pour les pare-feu et les anti-virus.</font> Bien que le document mentionne la politique de gestion des logs et la protection des logs, il n'est pas clair si les logs de pare-feu et d'anti-virus sont sauvegardés et examinés comme requis par l'exigence. Par conséquent, l'exigence n'est pas respectée.

### Version tolerant
![[Pasted image 20260626094709.png|230]]
L'orientation est non conforme car :

En effet, <font color="#ff0000">le document mentionne que les journaux d'événements sont activés, que les logs sont protégés contre toute altération intentionnelle ou accidentelle</font>, que les logs sont sauvegardés et que les logs sont revus régulièrement pour identifier les tendances inhabituelles ou non désirées. Cela correspond à l'exigence de cybersécurité qui exige que l'activité de journalisation de la protection/détecte du matériel ou du logiciel (par exemple, les pare-feu, les anti-virus) soit activée, sauvegardée et revue.

## Cas mauvaise compréhension d'exception
En effet, le document mentionne que les équipements non-connectés ne sont pas repris dans l'inventaire car ils ne sont pas configurés et ne contiennent pas de données (cf. par exemple : zero client). Cela suggère que les non-connectés ne sont pas considérés comme des actifs à documenter.