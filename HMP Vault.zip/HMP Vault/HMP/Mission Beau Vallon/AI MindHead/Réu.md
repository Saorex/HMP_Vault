Refonte Pipeline IA -> permet de lire images et scan (multi-modal), nouveau modèle (ColPali). 
Refonte Template -> facilité à implémenter template mais dois passer par HMP
Pas d'hallucination sur le modèle à priori
Archiver le projet  -> RO
Historique des modifications